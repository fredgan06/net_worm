package cn.g_open.net_worm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetWormApplication
{

    public static void main(String[] args)
    {
        SpringApplication.run(NetWormApplication.class, args);
    }

    public void aa()
    {

    }
}
